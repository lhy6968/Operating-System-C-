#!/bin/bash
rm /dev/mydev
ls -l /dev/mydev
