#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <wait.h>
#include <unistd.h>

#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>


int main(int argc,char *argv[]){

	/* Implement the functions here */
	
	return 0;
}
